#!/bin/bash
# RUN_PERF.sh - run perf_harness.js for a set of entity counts and save outputs to perf_results.txt
set -euo pipefail
OUT=perf_results.txt
echo "Running perf harness" > "$OUT"
for n in 500 2000 5000; do
  echo "=== entities $n ===" >> "$OUT"
  node perf_harness.js $n 500 >> "$OUT" 2>&1 || echo "perf run failed for $n" >> "$OUT"
done
echo "Results in $OUT"
cat "$OUT"
