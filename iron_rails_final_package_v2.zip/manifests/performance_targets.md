# Performance Targets

Target: Adaptive FPS with priority on steady responsiveness.

- Desktop baseline: target 60 FPS sustained; allow adaptive down to 45 FPS during extreme peaks.
- Mobile baseline: target 45 FPS sustained; adaptive down to 30 FPS on low-end devices.
- Goal: 95th percentile framerate >= baseline for 30-second gameplay session on chosen test devices.

Test devices recommendation:
- Desktop: Chrome latest on mid-range CPU (Intel i5, integrated GPU)
- Mobile: iPhone X or equivalent, Android mid-range (Snapdragon 660 class)

Measurements to collect:
- frame time distribution
- GC pause durations and frequencies
- draw calls per frame
- active entity count per frame
