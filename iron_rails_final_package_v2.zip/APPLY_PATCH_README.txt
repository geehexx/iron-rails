APPLY_PATCH README
This package includes an APPLY_PATCH.sh script to help applying any .patch files included in patches/.
Usage:
1. Place this package root next to your repository, or extract files into the repository root.
2. Run: ./APPLY_PATCH.sh feat/docs-scaffold
3. Resolve any conflicts, run tests, and push branch. Open PR using PR_TEMPLATE.md content.
Notes:
- The script attempts to `git apply` all patches and `git add` created files. It is a convenience; review changes before pushing.
- If no patches directory exists in your repo, create files manually from scaffold/.
