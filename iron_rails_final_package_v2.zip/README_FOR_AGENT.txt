Iron Rails - Implementation Package for Agent

Contents:
- scaffold/: minimal Phaser + TypeScript + bitecs example and config files.
- wireframes/: improved wireframe PNGs for HUD, item flow, enemy spawn, pause modal.
- manifests/: asset manifest, enemy archetype manifest, curated asset candidate list, performance targets.
- docs/: ADRs and architecture docs in scaffold/docs.

Goal:
Provide an agent with everything needed to implement the initial scaffold files into the repository, add CI, and curate assets. The agent should inspect the repo, plan changes, and open PRs with minimal risk changes.

Instructions for agent are in AGENT_PROMPT.txt (root) - follow that verbatim.
