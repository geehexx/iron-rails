#!/bin/bash
# APPLY_PATCH.sh
# Convenience script to apply all .patch files in patches/ using git apply.
# Usage: ./APPLY_PATCH.sh <branch-name>
set -euo pipefail
BRANCH="${1:-feat/docs-scaffold}"
echo "Creating branch $BRANCH"
git checkout -b "$BRANCH"
APPLY_DIR="patches"
if [ ! -d "$APPLY_DIR" ]; then
  echo "No patches directory found. Copy scaffold files manually or use files in scaffold/"
  exit 0
fi
for p in "$APPLY_DIR"/*.patch; do
  [ -e "$p" ] || continue
  echo "Applying $p"
  git apply "$p" || { echo "git apply failed for $p"; exit 2; }
  # attempt to add new files
  # extract filenames from patch
  files=$(grep "^\+\+\+ b/" "$p" | sed -E 's/\+\+\+ b\///')
  for f in $files; do
    if [ -f "$f" ]; then
      git add "$f"
    fi
  done
done
git commit -m "Apply scaffold and docs patches"
echo "Patches applied and committed. Push branch and open PR."
