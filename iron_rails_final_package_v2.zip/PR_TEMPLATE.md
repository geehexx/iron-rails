# PR: Add initial scaffold, docs, and CI templates

Summary:
- Adds minimal scaffold (Phaser + Vite + TypeScript + bitecs).
- Adds ADRs for ECS and Spatial Partition.
- Adds CI template and basic docs: CONTRIBUTING, SECURITY, ARCHITECTURE.
- Adds wireframe assets and initial manifests for assets and enemy archetypes.
- Adds performance harness script (perf_harness.js).

Checklist:
- [ ] LICENSE added (MIT)
- [ ] CI passes (lint, build, audit)
- [ ] ADRs reviewed and accepted
- [ ] Asset candidates curated and added to docs/assets/
- [ ] Perf harness executed and results attached
