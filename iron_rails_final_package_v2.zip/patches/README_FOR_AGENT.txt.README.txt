Apply this patch as a new file README_FOR_AGENT.txt in the repo root.
Recommended commit message: 'chore: add README_FOR_AGENT.txt'.
