// perf_harness.js
// Node.js script to simulate ECS-style updates and measure update loop timings.
// Usage: node perf_harness.js [entities] [steps]
const n = parseInt(process.argv[2]||'1000',10);
const steps = parseInt(process.argv[3]||'500',10);

function createEntities(count){
  const positions = new Float32Array(count*2);
  const velocities = new Float32Array(count*2);
  for(let i=0;i<count;i++){
    positions[i*2] = Math.random()*1024;
    positions[i*2+1] = Math.random()*768;
    velocities[i*2] = (Math.random()-0.5)*50;
    velocities[i*2+1] = (Math.random()-0.5)*50;
  }
  return {positions, velocities, count};
}

function update(world, dt){
  const p = world.positions;
  const v = world.velocities;
  const c = world.count;
  for(let i=0;i<c;i++){
    const ix = i*2;
    p[ix] += v[ix]*dt;
    p[ix+1] += v[ix+1]*dt;
    // simple bounds wrap
    if(p[ix] < 0) p[ix] += 1024;
    if(p[ix] > 1024) p[ix] -= 1024;
    if(p[ix+1] < 0) p[ix+1] += 768;
    if(p[ix+1] > 768) p[ix+1] -= 768;
  }
}

function run(){
  const world = createEntities(n);
  const timings = [];
  for(let s=0;s<steps;s++){
    const t0 = Date.now();
    update(world, 1/60);
    const t1 = Date.now();
    timings.push(t1-t0);
  }
  timings.sort((a,b)=>a-b);
  const p50 = timings[Math.floor(timings.length*0.5)];
  const p90 = timings[Math.floor(timings.length*0.9)];
  const p99 = timings[Math.floor(timings.length*0.99)];
  console.log('entities', n, 'steps', steps, 'p50ms', p50, 'p90ms', p90, 'p99ms', p99);
}

run();
