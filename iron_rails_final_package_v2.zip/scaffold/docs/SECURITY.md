# Security

Report security issues to repo maintainers via email. CI enforces lockfile and `npm audit --audit-level=high`.

Do not accept packages with postinstall scripts without review.
