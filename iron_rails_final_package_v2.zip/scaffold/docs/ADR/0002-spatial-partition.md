# ADR 0002: Spatial Partition

Decision: Implement a grid-based spatial partition as default. Provide quadtree as optional.

API:
- register(entityId, aabb)
- update(entityId, aabb)
- remove(entityId)
- queryAABB(aabb) / queryRadius(center, r)

Cell size: default 256 px. Tune via perf harness.
