# ADR 0001: ECS Choice

Decision: Use bitECS (bitecs) as the project's ECS library.

Context:
- Need a minimal, fast, low-dependency ECS for browser games.

Consequences:
- Systems will be data-oriented and decoupled from render.
- Implement a thin adapter to map ECS transforms to Phaser sprites.
