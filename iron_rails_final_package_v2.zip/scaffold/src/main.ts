import 'phaser'
import GameScene from './scene/GameScene'

const config: Phaser.Types.Core.GameConfig = {
  type: Phaser.AUTO,
  width: 1280,
  height: 720,
  backgroundColor: '#1e1e1e',
  scene: [GameScene]
}

window.addEventListener('load', ()=>{
  // eslint-disable-next-line no-new
  new Phaser.Game(config)
})
