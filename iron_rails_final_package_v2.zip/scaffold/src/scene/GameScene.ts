import Phaser from 'phaser'
import { World, defineComponent, Types, addEntity, addComponent } from 'bitecs'

const Position = defineComponent({ x: Types.f32, y: Types.f32 })

export default class GameScene extends Phaser.Scene{
  world: any
  constructor(){
    super({key:'GameScene'})
  }
  preload(){
    // placeholder for assets
  }
  create(){
    this.world = {} // placeholder for bitecs world
    // small example: create entity
    // const eid = addEntity(this.world)
    // addComponent(this.world, Position, eid)
  }
  update(time:number, dt:number){
    // game loop should update ECS systems here
  }
}
