# ADR-NNNN: [Title of ADR]

**Status:** Proposed | Accepted | Implemented | Superseded by [ADR-XXXX](./NNNN-filename.md)
**Date:** YYYY-MM-DD

---

## Context

[What is the issue that we're seeing that is motivating this decision or change? Describe the context and problem domain.]

---

## Decision

[What is the change that we're proposing and/or doing? State the decision in a clear and concise manner.]

---

## Consequences

[What becomes easier or more difficult to do because of this change? What are the positive and negative consequences of this decision?]
